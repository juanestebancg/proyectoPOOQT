/*
 * Subversion.cpp
 *
 *  Created on: 22 may. 2018
 *      Author: juanes
 */

#include "Subversion.h"

Subversion::Subversion(){

}

void Subversion::setID(string s){
	ID_Subversion = s;
}

string Subversion::getID(){
	return ID_Subversion ;
}


Subversion::~Subversion(){

}



